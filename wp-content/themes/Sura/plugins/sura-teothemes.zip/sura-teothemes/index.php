<?php
/**
 * Plugin Name: Sura - Custom Post Types, Taxonomies and Pages setup
 * Plugin URI: http://teothemes.com
 * Description: Custom taxonomies, post types and pages setup for the Sura theme
 * Version: 1.0
 * Author: TeoThemes
 * Author URI: http://teothemes.com
 * Text Domain: teo
 * License: GPL3
 */

require_once( plugin_dir_path( __FILE__ ) .'/song_taxonomies.php' );
require_once( plugin_dir_path( __FILE__ ) .'/post_types.php' );

//custom fields for custom taxonomies
require_once( plugin_dir_path( __FILE__ ) .'/album_customfields.php' );
require_once( plugin_dir_path( __FILE__ ) .'/artist_customfields.php' );

add_action('init', 'teo_create_pages' );
function teo_create_pages() {
	$created = get_option('teo_created_pages');
	if($created == 'yes') {
		return;
	}
	else {
		//create pages for the album and artist landing pages
		$my_post = array(
		  'post_title'    => 'Albums landing page',
		  'post_content'  => '',
		  'post_status'   => 'publish',
		  'post_author'   => 1,
		  'post_type'	  => 'page',
		  'page_template' => 'page-template-albums.php'
		);

		// Insert the page into the database
		$id_albums = wp_insert_post( $my_post );

		$my_post = array(
		  'post_title'    => 'Songs landing page',
		  'post_content'  => '',
		  'post_status'   => 'publish',
		  'post_author'   => 1,
		  'post_type'	  => 'page',
		  'page_template' => 'page-template-songs.php'
		);

		// Insert the page into the database
		$id_songs = wp_insert_post( $my_post );

		$my_post = array(
		  'post_title'    => 'Discover landing page',
		  'post_content'  => '',
		  'post_status'   => 'publish',
		  'post_author'   => 1,
		  'post_type'	  => 'page',
		  'page_template' => 'page-template-discover.php'
		);

		// Insert the page into the database
		$id_discover = wp_insert_post( $my_post );

		$my_post = array(
		  'post_title'    => 'Blog page',
		  'post_content'  => '',
		  'post_status'   => 'publish',
		  'post_author'   => 1,
		  'post_type'	  => 'page',
		  'page_template' => 'page-template-blog.php'
		);

		// Insert the post into the database
		$id_blog = wp_insert_post( $my_post );

		add_option('teo_albums_page', $id_albums);
		add_option('teo_songs_page', $id_songs);
		add_option('teo_discover_page', $id_discover);
		add_option('teo_blog_page', $id_blog);
		add_option('teo_created_pages', 'yes');
	}
}