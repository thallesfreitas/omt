<?php
add_action( 'init', 'teo_song_taxonomies', 0 );

function teo_song_taxonomies() {

	//genres taxonomy
	$labels = array(
		'name'              => _x( 'Genres', 'taxonomy general name' ),
		'singular_name'     => _x( 'Genre', 'taxonomy singular name' ),
		'search_items'      => __( 'Search Genres' ),
		'all_items'         => __( 'All Genres' ),
		'parent_item'       => __( 'Parent Genre' ),
		'parent_item_colon' => __( 'Parent Genre:' ),
		'edit_item'         => __( 'Edit Genre' ),
		'update_item'       => __( 'Update Genre' ),
		'add_new_item'      => __( 'Add New Genre' ),
		'new_item_name'     => __( 'New Genre Name' ),
		'menu_name'         => __( 'Genre' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'genre' ),
	);

	register_taxonomy( 'genre', 'product', $args );

	//artist taxonomy
	$labels = array(
		'name'              => _x( 'Artists', 'taxonomy general name' ),
		'singular_name'     => _x( 'Artist', 'taxonomy singular name' ),
		'search_items'      => __( 'Search Artists' ),
		'all_items'         => __( 'All Artists' ),
		'parent_item'       => __( 'Parent Artist' ),
		'parent_item_colon' => __( 'Parent Artist:' ),
		'edit_item'         => __( 'Edit Artist' ),
		'update_item'       => __( 'Update Artist' ),
		'add_new_item'      => __( 'Add New Artist' ),
		'new_item_name'     => __( 'New Artist Name' ),
		'menu_name'         => __( 'Artists' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'artist' ),
	);

	register_taxonomy( 'artist', 'product', $args );

	//albums taxonomy
	$labels = array(
		'name'              => _x( 'Albums', 'taxonomy general name' ),
		'singular_name'     => _x( 'Album', 'taxonomy singular name' ),
		'search_items'      => __( 'Search Albums' ),
		'all_items'         => __( 'All Albums' ),
		'parent_item'       => __( 'Parent Album' ),
		'parent_item_colon' => __( 'Parent Album:' ),
		'edit_item'         => __( 'Edit Album' ),
		'update_item'       => __( 'Update Album' ),
		'add_new_item'      => __( 'Add New Album' ),
		'new_item_name'     => __( 'New Album Name' ),
		'menu_name'         => __( 'Albums' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'album' ),
	);

	register_taxonomy( 'album', 'product', $args );
}
?>