<?php
//custom fields for album
function teo_album_add_customfields() {
	// this will add the custom meta field to the add new term page
	?>

	<div class="form-field">
		<label for="term_meta[image]"><?php _e( 'Album image', 'teo' ); ?></label>
		<input class="image-input" type="text" name="term_meta[image]" id="term_meta[image]" value="">
		<button class="teo_upload_image_button button">Upload Image</button>
		<p class="description"></p>
	</div>

	<div class="form-field">
		<label for="term_meta[bgimage]"><?php _e( 'Album big background image(if this variation is used)', 'teo' ); ?></label>
		<input class="image-input" type="text" name="term_meta[bgimage]" id="term_meta[bgimage]" value="">
		<button class="teo_upload_image_button button">Upload Image</button>
		<p class="description"></p>
	</div>

	<div class="form-field">
		<label for="term_meta[spotify]"><?php _e( 'Spotify URL(if used)', 'teo' ); ?></label>
		<input type="text" name="term_meta[spotify]" id="term_meta[spotify]" value="">
	</div>

	<div class="form-field">
		<label for="term_meta[itunes]"><?php _e( 'iTunes URL(if used)', 'teo' ); ?></label>
		<input type="text" name="term_meta[itunes]" id="term_meta[itunes]" value="">
	</div>

	<div class="form-field">
		<label for="term_meta[youtube]"><?php _e( 'Youtube URL(if used)', 'teo' ); ?></label>
		<input type="text" name="term_meta[youtube]" id="term_meta[youtube]" value="">
	</div>

	<div class="form-field">
		<label for="term_meta[soundcloud]"><?php _e( 'SoundCloud URL(if used)', 'teo' ); ?></label>
		<input type="text" name="term_meta[soundcloud]" id="term_meta[soundcloud]" value="">
	</div>

	<div class="form-field">
		<label for="term_meta[beatport]"><?php _e( 'BeatPort URL(if used)', 'teo' ); ?></label>
		<input type="text" name="term_meta[beatport]" id="term_meta[beatport]" value="">
	</div>

	<div class="form-field">
		<label for="term_meta[date]"><?php _e( 'Release date ', 'teo' ); ?></label>
		<input type="text" name="term_meta[date]" id="term_meta[date]" value="">
	</div>

	<div class="form-field">
		<label for="term_meta[extra_title1]"><?php _e( 'Extra details - Title #1(if used)', 'teo' ); ?></label>
		<input type="text" name="term_meta[extra_title1]" id="term_meta[extra_title1]" value="">
		<p class="description"><?php _e("If you want to add any extra details other than the release date and genres, here's the place to do it", 'teo');?></p>
	</div>

	<div class="form-field">
		<label for="term_meta[extra_description1]"><?php _e( 'Extra details - Description #1(if used)', 'teo' ); ?></label>
		<textarea name="term_meta[extra_description1]" id="term_meta[extra_description1]"></textarea>
		<p class="description"><?php _e("If you want to add any extra details other than the release date and genres, here's the place to do it", 'teo');?></p>
	</div>

	<div class="form-field">
		<label for="term_meta[extra_title2]"><?php _e( 'Extra details - Title #2(if used)', 'teo' ); ?></label>
		<input type="text" name="term_meta[extra_title2]" id="term_meta[extra_title2]" value="">
		<p class="description"><?php _e("If you want to add any extra details other than the release date and genres, here's the place to do it", 'teo');?></p>
	</div>

	<div class="form-field">
		<label for="term_meta[extra_description2]"><?php _e( 'Extra details - Description #2(if used)', 'teo' ); ?></label>
		<textarea name="term_meta[extra_description2]" id="term_meta[extra_description2]"></textarea>
		<p class="description"><?php _e("If you want to add any extra details other than the release date and genres, here's the place to do it", 'teo');?></p>
	</div>

	<div class="form-field">
		<label for="term_meta[extra_title3]"><?php _e( 'Extra details - Title #3(if used)', 'teo' ); ?></label>
		<input type="text" name="term_meta[extra_title3]" id="term_meta[extra_title3]" value="">
		<p class="description"><?php _e("If you want to add any extra details other than the release date and genres, here's the place to do it", 'teo');?></p>
	</div>

	<div class="form-field">
		<label for="term_meta[extra_description3]"><?php _e( 'Extra details - Description #3(if used)', 'teo' ); ?></label>
		<textarea name="term_meta[extra_description3]" id="term_meta[extra_description3]"></textarea>
		<p class="description"><?php _e("If you want to add any extra details other than the release date and genres, here's the place to do it", 'teo');?></p>
	</div>
<?php
}
add_action( 'album_add_form_fields', 'teo_album_add_customfields', 10, 2 );

// Edit term page
function teo_album_edit_customfields($term) {
 
	// put the term ID into a variable
	$t_id = $term->term_id;
 
	// retrieve the existing value(s) for this meta field. This returns an array
	$term_meta = get_option( "teo_album_$t_id" ); 

	?>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[image]"><?php _e( 'Album image', 'teo' ); ?></label></th>
		<td>
			<input class="image-input" style="width: 70%" type="text" name="term_meta[image]" id="term_meta[image]" value="<?php echo isset( $term_meta['image'] ) ? esc_attr( $term_meta['image'] ) : ''; ?>">
			<button class="teo_upload_image_button button">Upload Image</button>
			<p class="description"></p>
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[bgimage]"><?php _e( 'Album big background image(if this variation is used)', 'teo' ); ?></label></th>
		<td>
			<input class="image-input" style="width: 70%" type="text" name="term_meta[bgimage]" id="term_meta[bgimage]" value="<?php echo isset( $term_meta['bgimage'] ) ? esc_attr( $term_meta['bgimage'] ) : ''; ?>">
			<button class="teo_upload_image_button button">Upload Image</button>
			<p class="description"></p>
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[spotify]"><?php _e( 'Spotify URL(if used)', 'teo' ); ?></label></th>
		<td>
			<input type="text" name="term_meta[spotify]" id="term_meta[spotify]" value="<?php echo isset( $term_meta['spotify'] ) ? esc_attr( $term_meta['spotify'] ) : ''; ?>">
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[itunes]"><?php _e( 'iTunes URL(if used)', 'teo' ); ?></label></th>
		<td>
			<input type="text" name="term_meta[itunes]" id="term_meta[itunes]" value="<?php echo isset( $term_meta['itunes'] ) ? esc_attr( $term_meta['itunes'] ) : ''; ?>">
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[youtube]"><?php _e( 'Youtube URL(if used)', 'teo' ); ?></label></th>
		<td>
			<input type="text" name="term_meta[youtube]" id="term_meta[youtube]" value="<?php echo isset( $term_meta['youtube'] ) ? esc_attr( $term_meta['youtube'] ) : ''; ?>">
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[soundcloud]"><?php _e( 'SoundCloud URL(if used)', 'teo' ); ?></label></th>
		<td>
			<input type="text" name="term_meta[soundcloud]" id="term_meta[soundcloud]" value="<?php echo isset($term_meta['soundcloud']) ? esc_attr( $term_meta['soundcloud'] ) : ''; ?>">
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[beatport]"><?php _e( 'BeatPort URL(if used)', 'teo' ); ?></label></th>
		<td>
			<input type="text" name="term_meta[beatport]" id="term_meta[beatport]" value="<?php echo isset( $term_meta['beatport'] ) ? esc_attr( $term_meta['beatport'] ) : ''; ?>">
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[date]"><?php _e( 'Release date', 'teo' ); ?></label></th>
		<td>
			<input type="text" name="term_meta[date]" id="term_meta[date]" value="<?php echo isset( $term_meta['date'] ) ? esc_attr( $term_meta['date'] ) : ''; ?>">
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[extra_title1]"><?php _e( 'Extra details - Title #1(if used)', 'teo' ); ?></label></th>
		<td>
			<input type="text" name="term_meta[extra_title1]" id="term_meta[extra_title1]" value="<?php echo isset( $term_meta['extra_title1'] ) ? esc_attr( $term_meta['extra_title1'] ) : ''; ?>">
			<p class="description"><?php _e("If you want to add any extra details other than the release date and genres, here's the place to do it", 'teo');?></p>
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[extra_description1]"><?php _e( 'Extra details - Description #1(if used)', 'teo' ); ?></label></th>
		<td>
			<textarea name="term_meta[extra_description1]" id="term_meta[extra_description1]"><?php echo isset( $term_meta['extra_description1'] ) ? esc_attr( $term_meta['extra_description1'] ) : ''; ?></textarea>
			<p class="description"><?php _e("If you want to add any extra details other than the release date and genres, here's the place to do it", 'teo');?></p>
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[extra_title2]"><?php _e( 'Extra details - Title #2(if used)', 'teo' ); ?></label></th>
		<td>
			<input type="text" name="term_meta[extra_title2]" id="term_meta[extra_title2]" value="<?php echo isset( $term_meta['extra_title2'] ) ? esc_attr( $term_meta['extra_title2'] ) : ''; ?>">
			<p class="description"><?php _e("If you want to add any extra details other than the release date and genres, here's the place to do it", 'teo');?></p>
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[extra_description2]"><?php _e( 'Extra details - Description #2(if used)', 'teo' ); ?></label></th>
		<td>
			<textarea name="term_meta[extra_description2]" id="term_meta[extra_description2]"><?php echo isset( $term_meta['extra_description2'] ) ? esc_attr( $term_meta['extra_description2'] ) : ''; ?></textarea>
			<p class="description"><?php _e("If you want to add any extra details other than the release date and genres, here's the place to do it", 'teo');?></p>
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[extra_title3]"><?php _e( 'Extra details - Title #3(if used)', 'teo' ); ?></label></th>
		<td>
			<input type="text" name="term_meta[extra_title3]" id="term_meta[extra_title3]" value="<?php echo isset( $term_meta['extra_title3'] ) ? esc_attr( $term_meta['extra_title3'] ) : ''; ?>">
			<p class="description"><?php _e("If you want to add any extra details other than the release date and genres, here's the place to do it", 'teo');?></p>
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[extra_description3]"><?php _e( 'Extra details - Description #3(if used)', 'teo' ); ?></label></th>
		<td>
			<textarea name="term_meta[extra_description3]" id="term_meta[extra_description3]"><?php echo isset( $term_meta['extra_description3'] ) ? esc_attr( $term_meta['extra_description3'] ) : ''; ?></textarea>
			<p class="description"><?php _e("If you want to add any extra details other than the release date and genres, here's the place to do it", 'teo');?></p>
		</td>
	</tr>


<?php
}
add_action( 'album_edit_form_fields', 'teo_album_edit_customfields', 10, 2 );

// Save extra taxonomy fields callback function.
function teo_album_save_customfields( $term_id ) {
	if ( isset( $_POST['term_meta'] ) ) {
		$t_id = $term_id;
		$term_meta = get_option( "teo_album_$t_id" );
		$cat_keys = array_keys( $_POST['term_meta'] );
		foreach ( $cat_keys as $key ) {
			if ( isset ( $_POST['term_meta'][$key] ) ) {
				$term_meta[$key] = $_POST['term_meta'][$key];
			}
		}
		// Save the option array.
		update_option( "teo_album_$t_id", $term_meta );
	}
}  
add_action( 'edited_album', 'teo_album_save_customfields', 10, 2 );  
add_action( 'create_album', 'teo_album_save_customfields', 10, 2 );
?>