<?php 
add_action('init', 'teo_post_types');
function teo_post_types() {
  $labels = array(
    'name' => _x('Events', 'post type general name', 'teo'),
    'singular_name' => _x('Event', 'post type singular name', 'teo'),
    'add_new' => _x('Add', 'portfolio_item', 'teo'),
    'add_new_item' => __('Add a new event', 'teo'),
    'edit_item' => __('Edit event', 'teo'),
    'new_item' => __('New event', 'teo'),
    'all_items' => __('All events', 'teo'),
    'view_item' => __('View event details', 'teo'),
    'search_items' => __('Search event', 'teo'),
    'not_found' =>  __('No event found', 'teo'),
    'not_found_in_trash' => __('No event in the trash.' , 'teo'), 
    'parent_item_colon' => '',
    'menu_name' => 'Events'

  );
  $args = array(
    'labels' => $labels,
    'public' => true,
    'publicly_queryable' => true,
    'show_ui' => true, 
    'show_in_menu' => true, 
    'query_var' => true,
    'rewrite' => true,
    'capability_type' => 'post',
    'has_archive' => true, 
    'hierarchical' => false,
    'menu_position' => null,
    'supports' => array('title', 'editor', 'author', 'thumbnail')
  ); 
  
  register_post_type('event',$args);
}
?>