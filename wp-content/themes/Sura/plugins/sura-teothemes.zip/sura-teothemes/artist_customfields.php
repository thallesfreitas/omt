<?php
//custom fields for artist
function teo_artist_add_customfields() {
	// this will add the custom meta field to the add new term page
	?>
	<div class="form-field">
		<label for="term_meta[shortname]"><?php _e( 'First name(or nickname)', 'teo' ); ?></label>
		<input class="image-input" style="width: 70%" type="text" name="term_meta[shortname]" id="term_meta[shortname]" value="">
		<p class="description">Used on the artist page, in order to avoid using the full name but rather a short name or a nickname.</p>
	</div>

	<div class="form-field">
		<label for="term_meta[shortdescription]"><?php _e( 'Short description that shows up in the header section', 'teo' ); ?></label>
		<input class="image-input" type="text" name="term_meta[shortdescription]" id="term_meta[shortdescription]" value="">
	</div>

	<div class="form-field">
		<label for="term_meta[image]"><?php _e( 'Artist image', 'teo' ); ?></label>
		<input class="image-input" type="text" name="term_meta[image]" id="term_meta[image]" value="">
		<button class="teo_upload_image_button button">Upload Image</button>
		<p class="description"></p>
	</div>

	<div class="form-field">
		<label for="term_meta[bgimage]"><?php _e( 'Background image on artist individual page', 'teo' ); ?></label>
		<input class="image-input" style="width: 70%" type="text" name="term_meta[bgimage]" id="term_meta[bgimage]" value="">
		<button class="teo_upload_image_button button">Upload Image</button>
		<p class="description"></p>
	</div>

	<div class="form-field">
		<label for="term_meta[website]"><?php _e( 'Artist official website(if it exists)', 'teo' ); ?></label>
		<input type="text" name="term_meta[website]" id="term_meta[website]" value="">
	</div>

	<div class="form-field">
		<label for="term_meta[facebook]"><?php _e( 'Facebook URL(if used)', 'teo' ); ?></label>
		<input type="text" name="term_meta[facebook]" id="term_meta[facebook]" value="">
	</div>

	<div class="form-field">
		<label for="term_meta[twitter]"><?php _e( 'Twitter URL(if used)', 'teo' ); ?></label>
		<input type="text" name="term_meta[twitter]" id="term_meta[twitter]" value="">
	</div>

	<div class="form-field">
		<label for="term_meta[youtube]"><?php _e( 'Youtube URL(if used)', 'teo' ); ?></label>
		<input type="text" name="term_meta[youtube]" id="term_meta[youtube]" value="">
	</div>

	<div class="form-field">
		<label for="term_meta[soundcloud]"><?php _e( 'SoundCloud URL(if used)', 'teo' ); ?></label>
		<input type="text" name="term_meta[soundcloud]" id="term_meta[soundcloud]" value="">
	</div>

	<div class="form-field">
		<label for="term_meta[beatport]"><?php _e( 'BeatPort URL(if used)', 'teo' ); ?></label>
		<input type="text" name="term_meta[beatport]" id="term_meta[beatport]" value="">
	</div>
<?php
}
add_action( 'artist_add_form_fields', 'teo_artist_add_customfields', 10, 2 );

// Edit term page
function teo_artist_edit_customfields($term) {
 
	// put the term ID into a variable
	$t_id = $term->term_id;
 
	// retrieve the existing value(s) for this meta field. This returns an array
	$term_meta = get_option( "teo_taxonomy_$t_id" ); 

	?>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[shortname]"><?php _e( 'First name(or nickname)', 'teo' ); ?></label></th>
		<td>
			<input type="text" name="term_meta[shortname]" id="term_meta[shortname]" value="<?php echo isset( $term_meta['shortname'] ) ? esc_attr( $term_meta['shortname'] ) : ''; ?>">
			<p class="description">Used on the artist page, in order to avoid using the full name but rather a short name or a nickname.</p>
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[shortdescription]"><?php _e( 'Short description that shows up in the header section', 'teo' ); ?></label></th>
		<td>
			<textarea name="term_meta[shortdescription]" id="term_meta[shortdescription]"><?php echo isset( $term_meta['shortdescription'] ) ? esc_attr( $term_meta['shortdescription'] ) : ''; ?></textarea>
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[image]"><?php _e( 'Artist image', 'teo' ); ?></label></th>
		<td>
			<input class="image-input" style="width: 70%" type="text" name="term_meta[image]" id="term_meta[image]" value="<?php echo isset( $term_meta['image'] ) ? esc_attr( $term_meta['image'] ) : ''; ?>">
			<button class="teo_upload_image_button button">Upload Image</button>
			<p class="description"></p>
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[bgimage]"><?php _e( 'Background image on artist individual page', 'teo' ); ?></label></th>
		<td>
			<input class="image-input" style="width: 70%" type="text" name="term_meta[bgimage]" id="term_meta[bgimage]" value="<?php echo isset( $term_meta['bgimage'] ) ? esc_attr( $term_meta['bgimage'] ) : ''; ?>">
			<button class="teo_upload_image_button button">Upload Image</button>
			<p class="description"></p>
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[website]"><?php _e( 'Artist official website(if it exists)', 'teo' ); ?></label></th>
		<td>
			<input type="text" name="term_meta[website]" id="term_meta[website]" value="<?php echo isset( $term_meta['website'] ) ? esc_attr( $term_meta['website'] ) : ''; ?>">
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[facebook]"><?php _e( 'Facebook URL(if used)', 'teo' ); ?></label></th>
		<td>
			<input type="text" name="term_meta[facebook]" id="term_meta[facebook]" value="<?php echo isset( $term_meta['facebook'] ) ? esc_attr( $term_meta['facebook'] ) : ''; ?>">
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[twitter]"><?php _e( 'Twitter URL(if used)', 'teo' ); ?></label></th>
		<td>
			<input type="text" name="term_meta[twitter]" id="term_meta[twitter]" value="<?php echo isset( $term_meta['twitter'] ) ? esc_attr( $term_meta['twitter'] ) : ''; ?>">
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[youtube]"><?php _e( 'Youtube URL(if used)', 'teo' ); ?></label></th>
		<td>
			<input type="text" name="term_meta[youtube]" id="term_meta[youtube]" value="<?php echo isset( $term_meta['youtube'] ) ? esc_attr( $term_meta['youtube'] ) : ''; ?>">
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[soundcloud]"><?php _e( 'SoundCloud URL(if used)', 'teo' ); ?></label></th>
		<td>
			<input type="text" name="term_meta[soundcloud]" id="term_meta[soundcloud]" value="<?php echo isset($term_meta['soundcloud']) ? esc_attr( $term_meta['soundcloud'] ) : ''; ?>">
		</td>
	</tr>

	<tr class="form-field">
		<th scope="row" valign="top"><label for="term_meta[beatport]"><?php _e( 'BeatPort URL(if used)', 'teo' ); ?></label></th>
		<td>
			<input type="text" name="term_meta[beatport]" id="term_meta[beatport]" value="<?php echo isset( $term_meta['beatport'] ) ? esc_attr( $term_meta['beatport'] ) : ''; ?>">
		</td>
	</tr>
<?php
}
add_action( 'artist_edit_form_fields', 'teo_artist_edit_customfields', 10, 2 );

// Save extra taxonomy fields callback function.
function teo_artist_save_customfields( $term_id ) {
	if ( isset( $_POST['term_meta'] ) ) {
		$t_id = $term_id;
		$term_meta = get_option( "teo_taxonomy_$t_id" );
		$cat_keys = array_keys( $_POST['term_meta'] );
		foreach ( $cat_keys as $key ) {
			if ( isset ( $_POST['term_meta'][$key] ) ) {
				$term_meta[$key] = $_POST['term_meta'][$key];
			}
		}
		// Save the option array.
		update_option( "teo_taxonomy_$t_id", $term_meta );
	}
}  
add_action( 'edited_artist', 'teo_artist_save_customfields', 10, 2 );  
add_action( 'create_artist', 'teo_artist_save_customfields', 10, 2 );
?>